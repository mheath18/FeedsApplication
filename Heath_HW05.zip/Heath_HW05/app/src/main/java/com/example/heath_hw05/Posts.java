package com.example.heath_hw05;

public class Posts {
    String Name;
    String Postid;
    String CreatorId;
    String Message;
    String DateTime;

    public Posts(String name, String postid, String creatorId, String message, String dateTime) {
        Name = name;
        Postid = postid;
        CreatorId = creatorId;
        Message = message;
        DateTime = dateTime;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getPostid() {
        return Postid;
    }

    public void setPostid(String postid) {
        Postid = postid;
    }

    public String getCreatorId() {
        return CreatorId;
    }

    public void setCreatorId(String creatorId) {
        CreatorId = creatorId;
    }

    public String getMessage() {
        return Message;
    }

    public void setMessage(String message) {
        Message = message;
    }

    public String getDateTime() {
        return DateTime;
    }

    public void setDateTime(String dateTime) {
        DateTime = dateTime;
    }
}
