package com.example.heath_hw05;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link Register#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Register extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private static final String TAG = "Demo";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public Register() {
        // Required empty public constructor
    }


    // TODO: Rename and change types and number of parameters
    public static Register newInstance() {
        Register fragment = new Register();
        Bundle args = new Bundle();

        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        getActivity().setTitle("Create New Account");
        View view = inflater.inflate(R.layout.fragment_register, container, false);
        Button registerbtn= view.findViewById(R.id.btnRegisterSubmit);
        EditText fullname = view.findViewById(R.id.editTextTextRegName);
        EditText email = view.findViewById(R.id.editTextRegEmail);
        EditText password = view.findViewById(R.id.editTextRegPass);
        TextView cancel = view.findViewById(R.id.textViewCancelRegistration);

        registerbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name=  fullname.getText().toString();
                String mail = email.getText().toString();
                String pass=  password.getText().toString();
                Log.d(TAG, "onResponse: "+ name + mail+ pass);
                rListener.greeting(name);
                rListener.registerAccount(name,mail,pass);
            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                rListener.LogOut();
            }
        });

        return view;
    }

    RegisterListener rListener;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        rListener = (RegisterListener) context;
    }

    interface RegisterListener{
        void registerAccount(String name,String email,String password);
        void LogOut();
        String greeting(String user);
    }

}