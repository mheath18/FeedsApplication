package com.example.heath_hw05;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity implements Login.LoginListener, PostsList.PostListListener, CreatePost.CreatePostListener, Register.RegisterListener{
    private static final String TAG = "Demo";
    ArrayList<Posts> postsList = new ArrayList<>();
    private final OkHttpClient client = new OkHttpClient();
    public static final String Shared_prefs = "SharedPrefs";
    public static String CurrentUser = "";
    String token = "";
     String person="";
     public static String id="";
     int total=520;
     int page=1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


    }

    @Override
    public void gotoRegister() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragmentContainerView, Register.newInstance())
                .addToBackStack(null)
                .commit();
    }

    @Override
    public void loginIn(String username, String password) {

        FormBody formBody = new FormBody.Builder()
                .add(getString(R.string.email), username)
                .add(getString(R.string.password), password)
                .build();

        Request request = new Request.Builder()
                .url("https://www.theappsdr.com/posts/login")
                .post(formBody)
                .build();


        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                e.printStackTrace();
                Log.d(TAG, "onFailure: Failed");
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                Log.d(TAG, "onResponse: Worked");
                //if response is successful get response body'
                Log.d(TAG, "onResponse: Worked"+ response.isSuccessful());



                if (response.isSuccessful()) {

                    try {
                        JSONObject json = new JSONObject(response.body().string());
                        token= json.getString("token");
                        person= json.getString("user_fullname");
                        id= json.getString("user_id");

                        //share preferences
                        SharedPreferences sharedPref = getApplicationContext().getSharedPreferences(Shared_prefs, Context.MODE_PRIVATE);
                        SharedPreferences.Editor editor = sharedPref.edit();

                        editor.putString("token",token);
                        editor.putString("name", person);
                        editor.putString("password", password);
                        editor.putString("user_id", id);

                        editor.apply();

                      //  Toast.makeText(getApplication(),"Info saved",Toast.LENGTH_LONG).show();



                    } catch (JSONException e) {
                        e.printStackTrace();
                    }


                    Log.d(TAG, "onResponse: token and person" + token + person);
                    greeting(person);

                    getSupportFragmentManager().beginTransaction()
                            .replace(R.id.fragmentContainerView, PostsList.newInstance())
                            .addToBackStack(null)
                            .commit();
                }
                try {

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public String greeting(String user) {
        CurrentUser= user;
        return user;
    }



    @Override
    public void gotoCreatePost() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragmentContainerView, CreatePost.newInstance())
                .addToBackStack(null)
                .commit();
    }

    @Override
    public void updatePage() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragmentContainerView, PostsList.newInstance())
                .addToBackStack(null)
                .commit();
    }

    @Override
    public void registerAccount(String name, String email, String password) {

        FormBody formBody = new FormBody.Builder()
                .add("email", email)
                .add("password", password)
                .add("name", name)
                .build();

        Request request = new Request.Builder()
                .url("https://www.theappsdr.com/posts/signup")
                .addHeader("Authorization", "BEARER "  + token)
                .post(formBody)
                .build();


        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                e.printStackTrace();
                Log.d(TAG, "onFailure: Failed");
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                //if response is successful get response body'

                if (response.isSuccessful()) {

                    try {
                        JSONObject jsonObject = new JSONObject(response.body().string());
                        Log.d(TAG, "onResponse: status"+  response.isSuccessful() );
                        Log.d(TAG, "onResponse: Worked"+ jsonObject.getString("message") + response.isSuccessful() );

                        token= jsonObject.getString("token");
                        person= jsonObject.getString("user_fullname");

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    Log.d(TAG, "onResponse: token and person" + getToken() + person);

                    loginIn(email,password);


                }

            }
        });


    }

    @Override
    public void LogOut() {
        setPerson("");
        setToken("");
        getSupportFragmentManager().beginTransaction()
               .replace(R.id.fragmentContainerView, new Login())
                .addToBackStack(null)
                .commit();

              //  .commit();
    }

    @Override
    public int getPage() {
        return page;
    }


    @Override
    public String getUser() {

        return CurrentUser;
    }

    @Override
    public String getToken() {
        return token;
    }

    @Override
    public void storingPage(int page, int total) {
        this.total=total;
        this.page= page;
    }

    @Override
    public int getTotalPage() {
        return total;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public void setPerson(String person) {
        this.person = person;
    }

    @Override
    public void gotoPostList() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragmentContainerView, PostsList.newInstance())
                .addToBackStack(null)
                .commit();
    }

    @Override
    public void ReturnPost(String message) {

        FormBody formBody = new FormBody.Builder()
                .add("post_text", message)
                .build();

        Request request = new Request.Builder()
                .url("https://www.theappsdr.com/posts/create")
                .addHeader("Authorization", "BEARER "  + token)
                .post(formBody)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                e.printStackTrace();
                Log.d(TAG, "onFailure: Failed");
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                //if response is successful get response body'

                if (response.isSuccessful()) {

                    try {
                        JSONObject jsonObject = new JSONObject(response.body().string());
                        Log.d(TAG, "onResponse: status"+  response.isSuccessful() );
                        Log.d(TAG, "onResponse: Worked"+ jsonObject.getString("message") + response.isSuccessful() );
                        setToken( jsonObject.getString("token"));
                        setPerson(jsonObject.getString("user_fullname"));

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    getSupportFragmentManager().beginTransaction()
                            .replace(R.id.fragmentContainerView, PostsList.newInstance())
                            .addToBackStack(null)
                            .commit();
                }

            }
        });

    }



}