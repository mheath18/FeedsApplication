package com.example.heath_hw05;

import static android.view.View.GONE;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link PostsList#newInstance} factory method to
 * create an instance of this fragment.
 */
public class PostsList extends Fragment implements postPageAdapter.postPageAdapterListener, PostItemAdapter.postItemAdapterListener{
    RecyclerView buttonView ;
    LinearLayoutManager buttonLayout;
    postPageAdapter adapterButton;

    LinearLayoutManager layoutManager;
    RecyclerView recyclerView;
    PostItemAdapter adapter;
    ArrayList<Posts> Posts = new ArrayList<>();
    ArrayList<Integer> numbers = new ArrayList<>();
    private static final String TAG = "Demo";
    private final OkHttpClient client = new OkHttpClient();
    String Name;
    String Postid;
    String CreatorId;
    String Message;
    String DateTime;
    Posts post;
    String token;
    int totalposts ;
    boolean runner= false;
    int pageHolder =1 ;
    int page2;

    public PostsList() {
        // Required empty public constructor
    }


    // TODO: Rename and change types and number of parameters
    public static PostsList newInstance() {
        PostsList fragment = new PostsList();
        Bundle args = new Bundle();

        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        pageHolder= pListener.getPage();
        View view = inflater.inflate(R.layout.fragment_posts_list, container, false);
        getActivity().setTitle("Posts");
        Button createPost = view.findViewById(R.id.btnCreatePost);
        Button logout = view.findViewById(R.id.btnLogout);
        TextView greetingM = view.findViewById(R.id.textViewWelcomeUser);
        greetingM.setText("Welcome " + pListener.getUser());
        TextView PageIndex = view.findViewById(R.id.textViewPageCounter);
        recyclerView = view.findViewById(R.id.RecycleView);
        buttonView= view.findViewById(R.id.numberbar);


        createPost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pListener.gotoCreatePost();
            }
        });

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pListener.LogOut();
            }
        });

        recyclerView = view.findViewById(R.id.RecycleView);
        //layoutManager = new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false);
        layoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(layoutManager);
        adapter = new PostItemAdapter(Posts,this);
        recyclerView.setAdapter(adapter);
        getPosts();


        PageIndex.setText(PageIndex(pageHolder, pListener.getTotalPage()/10));

        buttonView= view.findViewById(R.id.numberbar);
        buttonLayout= new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false);
        buttonView.setLayoutManager(buttonLayout);
        adapterButton = new postPageAdapter(numbers,this);
        buttonView.setAdapter(adapterButton);




        return view;
    }

    public void getPosts() {
        //FIX TOKEN BASED ON USER LOGIN

         token = pListener.getToken();
             Request request = new Request.Builder()
                     .url("https://www.theappsdr.com/posts?page="+ pageHolder)
                     .addHeader("Authorization", "BEARER " + token)
                     .build();

        Log.d(TAG, "getPosts: " + pageHolder);
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
                Log.d(TAG, "onFailure: Failed");
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                Log.d(TAG, "onResponse: Worked");
                //if response is successful get response body
                if (response.isSuccessful()) {
                    try {

                        JSONObject jsonObject = new JSONObject(response.body().string());
                        JSONArray posts = jsonObject.getJSONArray("posts");
                        totalposts = Integer.parseInt(jsonObject.getString("totalCount"));
                        //total post determinator
                        Log.d(TAG, "CCCCCCCCCCCC" + totalposts);
                        for (int i=1; i< (totalposts/10) ;i++){
                            numbers.add(i);
                        }

                        int q = Integer.parseInt(jsonObject.getString("pageSize"));

                        for (int i = 0; i < q; i++) {
                            Name = posts.getJSONObject(i).getString("created_by_name");
                            Postid = posts.getJSONObject(i).getString("post_id");
                            CreatorId = posts.getJSONObject(i).getString("created_by_uid");
                            Message = posts.getJSONObject(i).getString("post_text");
                            DateTime = posts.getJSONObject(i).getString("created_at");

                            post = new Posts(Name, Postid, CreatorId, Message, DateTime);
                            Posts.add(post);
                            Log.d(TAG, "On response: poost size: " + Posts.size());
                        }

                        // Update the adapter so that the listview can display the new data
                        getActivity().runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                adapter.notifyDataSetChanged();
                                adapterButton.notifyDataSetChanged();

                            }
                        });

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }


                }

                if (runner == true ){

                    pListener.updatePage();
                }

            }
        });
      }


      public String PageIndex(int index, int totalposts){
           return "Showing Page " + index+ " Out of "+totalposts ;
      }

      PostListListener pListener;

        @Override
        public void onAttach (@NonNull Context context){
            super.onAttach(context);
            pListener = (PostListListener) context;
        }

    @Override
    public void PageNavigator(int pos) {
            runner=true;
      //pageHolder= pos;
        pListener.storingPage(pos,totalposts);
        Log.d(TAG, "PageNavigator: " + "test10000 :)))" + pos);
      getPosts();

    }

    @Override
    public void deletePost(int pos) {
        String postIdHolder = Posts.get(pos).Postid;

        FormBody formBody = new FormBody.Builder()
                .add("post_id", postIdHolder)
                .build();

        Request request = new Request.Builder()
                .url("https://www.theappsdr.com/posts/delete")
                .addHeader("Authorization", "BEARER "  + token)
                .post(formBody)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
                //Log.d(TAG, "onFailure: Post Failed");

            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {

                //Log.d(TAG, "onResponse: POST Worked. Successful = " + response.isSuccessful());
                //if response is successful get response body
                if (response.isSuccessful()) {
                    //Log.d(TAG, "onResponse: successful = " + response.isSuccessful());
                   pListener.updatePage();

                }

            }
        });



    }

    interface PostListListener {
            void gotoCreatePost();
            void updatePage();
            void LogOut();
            int getPage();
            String getUser();
            String getToken();
            void storingPage(int page, int total);
            int getTotalPage();
        }


    }