package com.example.heath_hw05;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link Login#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Login extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private static final String TAG = "Demo";
    public static final String Shared_prefs = "SharedPrefs";
    private final OkHttpClient client = new OkHttpClient();
    private String saveduser;
    private String savedpword;


    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public Login() {
        // Required empty public constructor
    }


    public static Login newInstance(String param1, String param2) {
        Login fragment = new Login();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_login, container, false);
        getActivity().setTitle(getString(R.string.titlelogin));

        Button btnLogin= view.findViewById(R.id.btnLogin);
        TextView register= view.findViewById(R.id.textView3);
        EditText username = view.findViewById(R.id.editTextTextEmailAddress);
        EditText password = view.findViewById(R.id.editTextTextPassword);


        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String uname = username.getText().toString();
                String pword = password.getText().toString();
                Log.d(TAG, "onResponse: "+ uname + pword);
                lListener.greeting(uname);
                lListener.loginIn(uname,pword);



                username.setText(saveduser);
                password.setText(savedpword);

            }
        });

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                lListener.gotoRegister();

            }
        });
        return view;

    }

    LoginListener lListener;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        lListener = (LoginListener) context;
    }

    interface LoginListener{
        void gotoRegister();
        void loginIn(String username, String password);
        public String greeting(String user);
    }


}