package com.example.heath_hw05;

import android.annotation.SuppressLint;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class postPageAdapter extends RecyclerView.Adapter<postPageAdapter.UserViewHolder> {
    ArrayList<Integer> numbers;
    //RecycleViewExpensesFragAdapter.IRecycleViewExpensesFragAdapter mRecycleViewExpensesFragAdapter;

    public postPageAdapter(ArrayList<Integer> data, postPageAdapterListener adapter) {
        //this.mRecycleViewExpensesFragAdapter = adapter;
        this.numbers = data;
        this.pageListener = adapter;

    }

    @NonNull
    @Override
    public postPageAdapter.UserViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.pagenumbers, parent, false);
        postPageAdapter.UserViewHolder userViewHolder = new postPageAdapter.UserViewHolder(view);
        return userViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull postPageAdapter.UserViewHolder holder, @SuppressLint("RecyclerView") int position) {
        holder.position= position;
        if (!numbers.isEmpty()) {
            holder.number.setText(numbers.get(position).toString());
        }

        holder.number.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pageListener.PageNavigator(position + 1);
            }
        });

    }

    @Override
    public int getItemCount() {
        return this.numbers.size();
    }

    public static class UserViewHolder extends RecyclerView.ViewHolder {

        Button number = itemView.findViewById(R.id.numberbtn);
        int position;

        public UserViewHolder(@NonNull View itemView) {
            super(itemView);

        }
    }

    postPageAdapterListener pageListener;

    interface postPageAdapterListener{
       void PageNavigator(int pos);

    }


}
