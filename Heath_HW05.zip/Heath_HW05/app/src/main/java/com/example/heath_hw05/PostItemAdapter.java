package com.example.heath_hw05;

import static android.view.View.GONE;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class PostItemAdapter extends RecyclerView.Adapter<PostItemAdapter.UserViewHolder> {

    ArrayList<Posts> items;
    //RecycleViewExpensesFragAdapter.IRecycleViewExpensesFragAdapter mRecycleViewExpensesFragAdapter;

    public PostItemAdapter(ArrayList<Posts> data, postItemAdapterListener adapter) {
        //this.mRecycleViewExpensesFragAdapter = adapter;
        this.items = data;
        itemListener=adapter;
        //mRecycleViewExpensesFragAdapter = adapter;
        //mRecycleViewExpensesFragAdapter = adapter;
    }

    @NonNull
    @Override
    public PostItemAdapter.UserViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.postitem, parent, false);
        PostItemAdapter.UserViewHolder userViewHolder = new PostItemAdapter.UserViewHolder(view);
        return userViewHolder;
    }


    @Override
    public void onBindViewHolder(@NonNull PostItemAdapter.UserViewHolder holder, @SuppressLint("RecyclerView") int position) {

        if (!items.isEmpty()) {

            holder.message.setText(items.get(position).getMessage());
            holder.name.setText(items.get(position).getName());
            holder.timestamp.setText(items.get(position).getDateTime());


        }

        if ( !(MainActivity.id.equals(items.get(position).CreatorId) ) ){
            holder.trash.setVisibility(GONE);
        }

        holder.trash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                itemListener.deletePost(position);
            }
        });

    }

    @Override
    public int getItemCount() {
        return this.items.size();
    }

    public static class UserViewHolder extends RecyclerView.ViewHolder {

        TextView message = itemView.findViewById(R.id.textViewItemMessage);
        TextView name = itemView.findViewById(R.id.textViewItemName);
        TextView timestamp= itemView.findViewById(R.id.textViewItemTimeStamp);
        ImageButton trash = itemView.findViewById(R.id.btnItemDeletebtn);

        public UserViewHolder(@NonNull View itemView) {
            super(itemView);


        }


    }

    postItemAdapterListener itemListener;

    interface postItemAdapterListener{
        void deletePost(int pos);

    }


}
