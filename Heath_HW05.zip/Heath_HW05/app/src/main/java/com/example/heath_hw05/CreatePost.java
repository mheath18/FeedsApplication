package com.example.heath_hw05;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


/**
 * A simple {@link Fragment} subclass.
 * Use the {@link CreatePost#newInstance} factory method to
 * create an instance of this fragment.
 */
public class CreatePost extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";



    // TODO: Rename and change types of parameters


    public CreatePost() {
        // Required empty public constructor
    }


    // TODO: Rename and change types and number of parameters
    public static CreatePost newInstance() {
        CreatePost fragment = new CreatePost();
        Bundle args = new Bundle();

        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view= inflater.inflate(R.layout.fragment_create_post, container, false);
        getActivity().setTitle(getString(R.string.title));
        Button submitPost = view.findViewById(R.id.btnSubmitPost);
        TextView cancel = view.findViewById(R.id.textViewPostCancel);
        EditText messagepost = view.findViewById(R.id.editTextEnterPost);

        submitPost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cListener.ReturnPost(messagepost.getText().toString());

            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cListener.gotoPostList();
            }
        });

        return view;
    }

    CreatePostListener cListener;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        cListener = (CreatePostListener) context;
    }

    interface CreatePostListener{
        void gotoPostList();
        void ReturnPost(String message);
    }


}